## Module <ohrms_core>

#### 22.10.2018
#### Version 12.0.1.0.0
##### ADD
- Initial commit for Open HRMS Core Module